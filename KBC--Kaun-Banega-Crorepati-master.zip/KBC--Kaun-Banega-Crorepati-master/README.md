# KBC -Kaun Banega Crorepati
It is a core java game,based on Indian television show having best animation as possible in Core java.It contains 5000+ Lines of code and this projects is created just for learning purpose or you can also improve your quizzing skills.This Core java project have some amazing concepts Like Random question,All Lifelines which works fine,30 seconds to give answer and many more...<br/>


> **Note**
> If you are a noob in programming world than must see project source code to inspire yourself because now a day 
> i have experience of Solid Design Pattern and i usually break the code into small pieces and always try to write maximum 4-5 lines of  code in a function but in the starting of my programming carrer i had developed this project which contains around 5000+ lines of code without using functions except main function (Pffff).<br/>



This project is created by Rox Studio developer Just for Fun.


# Features
+ You have 7 Lifeline to give a Answer(Same as Provided on Television Show)
+ You will get unique question everytime
+ You have 30 second to give answer
+ Your score is Stored to Database
+ You can use Practise zone for Practicing your General knowledge
+ You can watch your high Score




# How to Run KBC- kaun Banega Crorepati
First Install netbeans and mysql (ENTER MYSQL PASSWORD:-12345) on  your computer





 MySQL Changes                              
-----------------------

+ After installing mysql Open it

+ Enter the command given below in Mysql

   create database kbc;

   use kbc;

   create table score(regid int(10) primary key auto_increment,name char(40),age int(3),score int(10));
+ Done


Netbeans
-----------------------
+ Open NetBeans

+ goto Service and connect kbc database.

+ then open project Simple

+ Run and Enjoy

# Requirements

Operating System  :-Platform Independent(win,linux,mac etc)

Software required :-Java Runtime Environment (JRE).

Library           :-mysql-connector-java-5.1.23-bin.jar

# Thank you


